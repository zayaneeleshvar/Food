package com.example.cart.database;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import io.reactivex.annotations.NonNull;

@Entity(tableName = "Cart")
public class CartItem {
         @PrimaryKey
         @NonNull
         @ColumnInfo(name ="FoodId")
         private String FoodId;

         @ColumnInfo(name ="FoodName")
         private String FoodName;

         @ColumnInfo(name ="FoodImage")
         private String FoodImage;

         @ColumnInfo(name ="FoodPrice")
         private Double FoodPrice;

         @ColumnInfo(name ="FoodQuantity")
         private int foodQuantity;

         @ColumnInfo(name ="UserPhone")
         private String UserPhone;

         @ColumnInfo(name ="FoodExtraPrice")
         private Double FoodExtraPrice;

         @ColumnInfo(name ="FoodAddon")
         private String FoodAddon;

         @ColumnInfo(name ="FoodSize")
         private String FoodSize;

         @ColumnInfo(name ="uid")
         private String uid;

    public String getFoodId() {
        return FoodId;
    }

    public void setFoodId(String foodId) {
        FoodId = foodId;
    }

    public String getFoodName() {
        return FoodName;
    }

    public void setFoodName(String foodName) {
        FoodName = foodName;
    }

    public String getFoodImage() {
        return FoodImage;
    }

    public void setFoodImage(String foodImage) {
        FoodImage = foodImage;
    }

    public Double getFoodPrice() {
        return FoodPrice;
    }

    public void setFoodPrice(Double foodPrice) {
        FoodPrice = foodPrice;
    }

    public int getFoodQuantity() {
        return foodQuantity;
    }

    public void setFoodQuantity(int foodQuantity) {
        this.foodQuantity = foodQuantity;
    }

    public String getUserPhone() {
        return UserPhone;
    }

    public void setUserPhone(String userPhone) {
        UserPhone = userPhone;
    }

    public Double getFoodExtraPrice() {
        return FoodExtraPrice;
    }

    public void setFoodExtraPrice(Double foodExtraPrice) {
        FoodExtraPrice = foodExtraPrice;
    }

    public String getFoodAddon() {
        return FoodAddon;
    }

    public void setFoodAddon(String foodAddon) {
        FoodAddon = foodAddon;
    }

    public String getFoodSize() {
        return FoodSize;
    }

    public void setFoodSize(String foodSize) {
        FoodSize = foodSize;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }
}
